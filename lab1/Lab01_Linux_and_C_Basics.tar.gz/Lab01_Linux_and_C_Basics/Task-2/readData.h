#include <stdio.h> 
#include <stdlib.h>

//typedef int num_t;

int* allocateMemory(int* , int);
int* readData( int* arr , int size);
