void do_transpose_standard (double* B, const double* A, int N);
void do_transpose_optimized(double* B, const double* A, int N);
