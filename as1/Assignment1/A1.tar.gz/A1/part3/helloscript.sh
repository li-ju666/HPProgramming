echo Hej hej
echo hello world! 
echo hello Uppsala! 
